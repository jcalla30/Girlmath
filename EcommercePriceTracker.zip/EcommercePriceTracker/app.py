import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter
from datetime import datetime, timedelta
import altair as alt
import keepa
import requests
from bs4 import BeautifulSoup
import re
import time
import random
from utils import extract_asin, get_amazon_product_info, search_walmart, girl_math_logic, get_girly_error_message, girl_math_statement

# Import database functions 
from database import get_recent_searches, get_favorites, toggle_favorite, get_product, save_product, add_search_history, is_favorite

# Initialize session states
if 'search_history' not in st.session_state:
    st.session_state.search_history = []
    
if 'view' not in st.session_state:
    st.session_state.view = "main"  # Can be 'main', 'history', 'favorites', 'login', 'signup'
    
if 'user_tier' not in st.session_state:
    st.session_state.user_tier = "free"  # Can be 'free', 'besties', 'platinum'
    
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    
if 'username' not in st.session_state:
    st.session_state.username = None
    
if 'user_id' not in st.session_state:
    st.session_state.user_id = None
    
if 'coupon_applied' not in st.session_state:
    st.session_state.coupon_applied = False
    
# Variable to store coupon code entry across forms
coupon_code = ""

# Page configuration
st.set_page_config(
    page_title="Girl Math Deal Finder",
    page_icon="💸",
    layout="wide",
)

# Custom CSS for pink theme and girly fonts
st.markdown("""
<style>
    /* Pink theme */
    .main {
        background-color: #fff0f5;
    }
    
    /* Headers */
    h1, h2, h3 {
        font-family: 'Pacifico', cursive;
        color: #FF69B4;
    }
    
    /* General text */
    p, div, label, span {
        font-family: 'Quicksand', sans-serif;
        color: #FF1493;
    }
    
    /* Streamlit widgets customization */
    .stButton button {
        background-color: #FF69B4;
        color: white;
        border-radius: 20px;
        border: none;
        font-family: 'Quicksand', sans-serif;
    }
    
    .stTextInput input {
        border-radius: 20px;
        border: 2px solid #FF69B4;
    }
    
    /* Card-like containers */
    .css-1r6slb0, .css-12oz5g7 {
        background-color: white;
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);
    }
    
    /* Success messages */
    .element-container .stAlert {
        background-color: #FFD1DC;
        border: 1px solid #FF69B4;
        border-radius: 20px;
    }

    /* Metrics */
    .stMetric {
        background-color: #FFD1DC;
        border-radius: 15px;
        padding: 10px;
        box-shadow: 0px 4px 8px rgba(255, 105, 180, 0.1);
    }

    /* Custom chart container */
    .chart-container {
        background-color: white;
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);
    }
    
    /* Footer */
    .footer {
        font-size: 12px;
        text-align: center;
        margin-top: 30px;
        color: #FF69B4;
    }
</style>

<!-- Import girly fonts -->
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
""", unsafe_allow_html=True)

# App Header
st.title("✨ Girl Math Deal Finder 💅")
st.markdown("### Find the best deals and justify your shopping with Girl Math! 💸💖")
st.markdown("---")

# Sidebar with explanation
with st.sidebar:
    st.markdown("## 💁‍♀️ What is Girl Math?")
    st.markdown("""
    Girl Math is a fun way to justify purchases by using creative 
    calculations that make spending feel like saving!
    
    **Examples:**
    - If it's on sale, you're *saving* money
    - If you use it more than once, divide the cost by uses
    - If it's under $5, it's basically free
    - If you return something, that's free money to spend
    """)
    
    st.markdown("---")
    st.markdown("## 💎 How to use")
    st.markdown("""
    1. Paste an Amazon product URL
    2. Wait for the price analysis
    3. See the Girl Math savings!
    4. Compare with Walmart prices
    5. Make a justified purchase 💕
    """)
    
    # Navigation
    st.markdown("---")
    st.markdown("## 🧭 Navigation")
    
    col_nav1, col_nav2, col_nav3 = st.columns(3)
    
    with col_nav1:
        if st.button("🏠 Home", use_container_width=True):
            st.session_state.view = "main"
            st.rerun()
    
    with col_nav2:
        if st.button("📜 History", use_container_width=True):
            st.session_state.view = "history"
            st.rerun()
    
    with col_nav3:
        if st.button("💖 Favorites", use_container_width=True):
            st.session_state.view = "favorites"
            st.rerun()
    
    # User account section
    st.markdown("---")
    st.markdown("## 👛 Your Account")
    
    if st.session_state.logged_in:
        # Show account info and logout button
        from database import get_user_tier_features
        tier_info = get_user_tier_features(st.session_state.user_tier)
        
        # Display tier information
        st.markdown(f"""
        <div style="background-color: {tier_info['background']}; padding: 15px; border-radius: 15px; margin: 10px 0;">
            <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 5px;">{tier_info['name']}</h3>
            <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; font-size: 14px;">
                <b>Username:</b> {st.session_state.username}
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Show tier features
        with st.expander("💅 Your Tier Features"):
            st.markdown(f"**{tier_info['name']}** - {tier_info['description']}")
            for feature in tier_info['features']:
                st.markdown(f"✓ {feature}")
        
        # Logout button
        if st.button("🚪 Logout", type="secondary"):
            # Clear user info from session state
            st.session_state.logged_in = False
            st.session_state.username = None
            st.session_state.user_id = None
            st.session_state.user_tier = "free"
            st.rerun()
    else:
        # Show login/signup buttons
        col_login, col_signup = st.columns(2)
        
        with col_login:
            if st.button("🔑 Login", use_container_width=True):
                st.session_state.view = "login"
                st.rerun()
                
        with col_signup:
            if st.button("✨ Sign Up", use_container_width=True):
                st.session_state.view = "signup"
                st.rerun()
    
    # Optional AI Analysis
    st.markdown("---")
    st.markdown("## 🧠 AI Analysis")
    
    # Option to use OpenAI for enhanced product insights (optional)
    with st.expander("Enhanced Girl Math Analysis (optional)"):
        st.write("For even more detailed shopping justifications and personalized analysis, you can connect OpenAI.")
        
        # Check if OpenAI API key is available
        try:
            has_openai_key = bool(st.secrets["OPENAI_API_KEY"])
            if has_openai_key:
                st.success("✅ OpenAI Connected - Enhanced analysis enabled!")
                ai_enabled = True
            else:
                ai_enabled = False
        except:
            ai_enabled = False
            st.info("OpenAI integration is optional and provides enhanced product analysis.")
            
    # Always use demo mode
    demo_mode = True
    keepa_api_key = "demo"  # Placeholder value for demo mode



# Main content based on selected view
if st.session_state.view == "main":
    # Main/Home View
    col1, col2 = st.columns([3, 1])
    
    with col1:
        amazon_url = st.text_input("Paste an Amazon Product Link:", placeholder="https://www.amazon.com/dp/...")
elif st.session_state.view == "history":
    # History View
    st.markdown("## 📚 Your Search History")
    
    # Get from database instead of session state
    search_history = get_recent_searches(limit=20)
    
    if search_history:
        for item in search_history:
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                title = item.get('title', 'Unknown Product')
                price = item.get('current_price', 0.0)
                date = item.get('search_date', '')
                date_str = date.split('T')[0] if 'T' in date else date
                
                st.markdown(f"""
                <div style="background-color: white; padding: 10px; border-radius: 10px; margin: 5px 0; border-left: 4px solid #FF69B4;">
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; margin: 0; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 400px;">
                        {title}
                    </p>
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF69B4; margin: 0; font-size: 14px;">
                        Price: <b>${price:.2f}</b> • Viewed: {date_str}
                    </p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                if item.get('asin'):
                    if item.get('url'):
                        st.markdown(f"<a href='{item['url']}' target='_blank'><button style='background-color: #FFD1DC; color: #FF1493; padding: 5px 10px; border: 1px solid #FF69B4; border-radius: 10px; cursor: pointer; font-family: \"Quicksand\", sans-serif; font-size: 12px; width: 100%;'>View on Amazon</button></a>", unsafe_allow_html=True)
            
            with col3:
                if item.get('asin'):
                    is_fav = is_favorite(item['asin'])
                    fav_text = "♥ Remove" if is_fav else "♡ Favorite" 
                    fav_color = "#FF1493" if is_fav else "#FF69B4"
                    bg_color = "#FFD1DC" if is_fav else "white"
                    
                    if st.button(fav_text, key=f"fav_{item['asin']}", help="Add or remove from favorites"):
                        toggle_favorite(item['asin'])
                        st.rerun()
    else:
        st.markdown("""
        <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0; text-align: center;">
            <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; font-size: 16px;">
                No search history yet! Start searching for products to see your history here.
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Add button to go back to main page
        if st.button("🔍 Search for Products", use_container_width=True):
            st.session_state.view = "main"
            st.rerun()
            
elif st.session_state.view == "favorites":
    # Favorites View
    st.markdown("## 💖 Your Favorite Products")
    
    # Get favorites from database
    favorites = get_favorites()
    
    if favorites:
        for item in favorites:
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                title = item.get('title', 'Unknown Product')
                price = item.get('current_price', 0.0)
                notes = item.get('notes', '')
                date = item.get('added_at', '')
                date_str = date.split('T')[0] if 'T' in date else date
                
                st.markdown(f"""
                <div style="background-color: white; padding: 10px; border-radius: 10px; margin: 5px 0; border-left: 4px solid #FF1493;">
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; margin: 0; font-size: 15px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 400px;">
                        {title}
                    </p>
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF69B4; margin: 0; font-size: 14px;">
                        Price: <b>${price:.2f}</b> • Added: {date_str}
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                # Display notes if available
                if notes:
                    st.markdown(f"""
                    <div style="background-color: #FFF0F5; padding: 5px; border-radius: 5px; margin-top: 2px;">
                        <p style="font-family: 'Quicksand', sans-serif; color: #FF69B4; margin: 0; font-size: 12px; font-style: italic;">
                            Note: {notes}
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
            
            with col2:
                # Amazon link
                amazon_url = f"https://www.amazon.com/dp/{item['asin']}"
                st.markdown(f"<a href='{amazon_url}' target='_blank'><button style='background-color: #FFD1DC; color: #FF1493; padding: 5px 10px; border: 1px solid #FF69B4; border-radius: 10px; cursor: pointer; font-family: \"Quicksand\", sans-serif; font-size: 12px; width: 100%;'>View on Amazon</button></a>", unsafe_allow_html=True)
            
            with col3:
                # Remove from favorites
                if st.button("Remove", key=f"remove_{item['asin']}", help="Remove from favorites"):
                    toggle_favorite(item['asin'])
                    st.rerun()
    else:
        st.markdown("""
        <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0; text-align: center;">
            <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; font-size: 16px;">
                No favorites yet! Heart products you love to see them here.
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Add button to go back to main page
        if st.button("🔍 Search for Products", use_container_width=True):
            st.session_state.view = "main"
            st.rerun()
elif st.session_state.view == "login":
    # Login View
    st.markdown("## 🔑 Login")
    
    # Create login form
    with st.form("login_form"):
        username = st.text_input("Username:", placeholder="Enter your username")
        password = st.text_input("Password:", type="password", placeholder="Enter your password")
        
        col1, col2 = st.columns(2)
        with col1:
            submit_button = st.form_submit_button("Login", use_container_width=True)
        with col2:
            back_button = st.form_submit_button("Back to Home", use_container_width=True)
    
    # Handle form submission
    if submit_button:
        if username and password:
            # Import login function
            from database import check_login
            
            # Check credentials
            user_info = check_login(username, password)
            
            if user_info:
                # Login successful
                st.session_state.logged_in = True
                st.session_state.username = user_info['username']
                st.session_state.user_id = user_info['id']
                st.session_state.user_tier = user_info['tier']
                
                st.success("Login successful! Redirecting to home...")
                st.session_state.view = "main"
                st.rerun()
            else:
                st.error("Invalid username or password. Please try again.")
        else:
            st.warning("Please enter both username and password.")
    
    if back_button:
        st.session_state.view = "main"
        st.rerun()
    
    # Add coupon code option
    st.markdown("---")
    st.markdown("### 💎 Have a Coupon Code?")
    
    with st.form("coupon_form"):
        coupon_code = st.text_input("Enter your coupon code:", placeholder="Enter code here")
        apply_coupon = st.form_submit_button("Apply Coupon", use_container_width=True)
    
    if apply_coupon and coupon_code:
        if coupon_code.lower() == "crystalcallahan":
            # Special message for Crystal Callahan coupon
            st.markdown("""
            <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 15px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
                <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">✨ PLATINUM ACCESS GRANTED! ✨</h3>
                <p style="font-family: 'Quicksand', sans-serif; font-size: 18px; color: #FF1493;">
                    slayyyyy queen buy Josie something nice 💅
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            st.session_state.coupon_applied = True
            st.info("Please login or create an account to use this coupon.")
        else:
            st.error("Invalid coupon code. Please try again.")

elif st.session_state.view == "signup":
    # Signup View
    st.markdown("## ✨ Create an Account")
    
    # Create signup form
    with st.form("signup_form"):
        username = st.text_input("Username:", placeholder="Choose a username")
        password = st.text_input("Password:", type="password", placeholder="Choose a password")
        confirm_password = st.text_input("Confirm Password:", type="password", placeholder="Confirm your password")
        email = st.text_input("Email (optional):", placeholder="Enter your email address")
        
        # Tier selection
        tier_options = {
            "free": "Barbie Basic (Free)",
            "besties": "Clueless Besties ($0.99/month)",
            "platinum": "Mean Girls Platinum ($5.00/month)"
        }
        
        selected_tier = st.radio("Select your tier:", options=list(tier_options.keys()), format_func=lambda x: tier_options[x])
        
        col1, col2 = st.columns(2)
        with col1:
            submit_button = st.form_submit_button("Create Account", use_container_width=True)
        with col2:
            back_button = st.form_submit_button("Back to Home", use_container_width=True)
    
    # Handle form submission
    if submit_button:
        if username and password and confirm_password:
            if password != confirm_password:
                st.error("Passwords do not match. Please try again.")
            else:
                # Import create_user function
                from database import create_user, apply_coupon
                
                # Create account
                user_id = create_user(username, password, email, selected_tier)
                
                if user_id:
                    # Check if we have a coupon to apply
                    if st.session_state.coupon_applied:
                        apply_coupon("crystalcallahan", user_id)
                        selected_tier = "platinum"
                        
                        # Special message for Crystal Callahan coupon
                        st.markdown("""
                        <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 15px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
                            <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">✨ PLATINUM ACCESS GRANTED! ✨</h3>
                            <p style="font-family: 'Quicksand', sans-serif; font-size: 18px; color: #FF1493;">
                                slayyyyy queen buy Josie something nice 💅
                            </p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                    # Account created successfully
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.session_state.user_id = user_id
                    st.session_state.user_tier = selected_tier
                    
                    st.success("Account created successfully! Redirecting to home...")
                    st.session_state.view = "main"
                    st.rerun()
                else:
                    st.error("Username already exists. Please choose a different username.")
        else:
            st.warning("Please fill in all required fields.")
    
    if back_button:
        st.session_state.view = "main"
        st.rerun()
    
    # Add coupon code option
    st.markdown("---")
    st.markdown("### 💎 Have a Coupon Code?")
    
    with st.form("coupon_form"):
        coupon_code = st.text_input("Enter your coupon code:", placeholder="Enter code here")
        apply_coupon = st.form_submit_button("Apply Coupon", use_container_width=True)
    
    if apply_coupon and coupon_code:
        if coupon_code.lower() == "crystalcallahan":
            # Special message for Crystal Callahan coupon
            st.markdown("""
            <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 15px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
                <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">✨ PLATINUM ACCESS GRANTED! ✨</h3>
                <p style="font-family: 'Quicksand', sans-serif; font-size: 18px; color: #FF1493;">
                    slayyyyy queen buy Josie something nice 💅
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            st.session_state.coupon_applied = True
        else:
            st.error("Invalid coupon code. Please try again.")

else:
    # Default to main view
    st.session_state.view = "main"
    amazon_url = st.text_input("Paste an Amazon Product Link:", placeholder="https://www.amazon.com/dp/...")

# Process the URL
if amazon_url:
    asin = extract_asin(amazon_url)
    
    # Add error handling for URL
    if not asin and amazon_url:
        st.error("Couldn't extract a valid Amazon product ID. Please check your URL and try again.")
    
    if asin:
        with st.spinner("💖 Applying Girl Math magic to find you a deal..."):
            try:
                # Attempt to find product in database
                
                # Try to get from database first
                product_info = get_product(asin)
                
                # If not in database, generate data and save it
                if not product_info:
                    # Special case for the Acer Nitro V Gaming Laptop
                    if asin == "7D2K2Wr":
                        product_info = {
                            'title': "Acer Nitro V Gaming Laptop | Intel Core i5-13420H | NVIDIA GeForce RTX 4050 | 15.6\" FHD 144Hz Display | 8GB DDR5 | 512GB SSD",
                            'current_price': 799.99,
                            'peak_price': 899.99,
                            'lowest_price': 749.99,
                            'asin': asin,
                            'demo': True
                        }
                        
                        # Generate realistic price history
                        import random
                        import numpy as np
                        price_data = []
                        for i in range(90):
                            if i < 30:  # First month - near peak price
                                price_data.append(random.uniform(869.99, 899.99))
                            elif i < 60:  # Second month - gradual decrease
                                price_data.append(random.uniform(829.99, 869.99))
                            else:  # Last month - current prices with occasional dips to lowest
                                if random.random() > 0.8:  # 20% chance of sale price
                                    price_data.append(random.uniform(749.99, 779.99))
                                else:
                                    price_data.append(random.uniform(789.99, 819.99))
                        
                        # Ensure last 5 days are close to current price
                        for i in range(1, 6):
                            price_data[-i] = random.uniform(product_info['current_price'] - 10, product_info['current_price'] + 10)
                            
                        product_info['price_data'] = price_data
                    else:
                        # Regular processing for other products
                        api = None  # Placeholder, not used
                        product_info = get_amazon_product_info(api, asin, demo_mode=False)  # Use real web scraping for data
                    
                    # Save to database
                    if product_info:
                        save_product(product_info)
                
                # Add to search history
                add_search_history(asin=asin, url=amazon_url)
                
                if not product_info:
                    st.error("Couldn't retrieve product information. Please check the URL or try again later.")
                    st.stop()
                
                product_title = product_info['title']
                
                # Display product info
                st.markdown(f"## {product_title}")
                
                # Extract relevant price data
                price_data = product_info['price_data']
                current_price = product_info['current_price']
                peak_price = product_info['peak_price']
                lowest_price = product_info['lowest_price']
                
                # Create price history chart
                st.markdown("### 📈 Price History")
                
                # Prepare data for chart
                chart_data = pd.DataFrame({
                    'date': [datetime.now() - timedelta(hours=len(price_data) - i) for i in range(len(price_data))],
                    'price': price_data
                })
                
                # Remove null values
                chart_data = chart_data[chart_data['price'] > 0]
                
                # Create Altair chart with pink theme
                chart = alt.Chart(chart_data).mark_line(
                    color='#FF69B4',
                    point=alt.OverlayMarkDef(color="#FF1493")
                ).encode(
                    x=alt.X('date:T', title='Date'),
                    y=alt.Y('price:Q', title='Price ($)', scale=alt.Scale(zero=False)),
                    tooltip=['date:T', 'price:Q']
                ).properties(
                    height=300
                ).interactive()
                
                st.altair_chart(chart, use_container_width=True)
                
                # Display price metrics
                st.markdown("### 💰 Price Analysis")
                
                col_current, col_peak, col_lowest = st.columns(3)
                with col_current:
                    st.metric("Current Price", f"${current_price:.2f}")
                with col_peak:
                    st.metric("Peak Price", f"${peak_price:.2f}", delta=f"-{peak_price - current_price:.2f}")
                with col_lowest:
                    delta = lowest_price - current_price
                    delta_text = f"{delta:.2f}" if delta < 0 else f"+{delta:.2f}"
                    st.metric("Lowest Price", f"${lowest_price:.2f}", delta=delta_text)
                
                # Girl Math calculation
                savings, percent = girl_math_logic(current_price, peak_price, lowest_price)
                
                # Display Girl Math results
                st.markdown("### ✨ Girl Math Results")
                
                # Create a styled box for the Girl Math results
                st.markdown(f"""
                <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 10px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
                    <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">By Girl Math Logic...</h3>
                    <p style="font-family: 'Quicksand', sans-serif; font-size: 18px; color: #FF1493;">
                        You're <b>saving ${savings:.2f}</b> ({percent:.1f}% off peak price)!
                    </p>
                    <p style="font-family: 'Quicksand', sans-serif; font-size: 16px; color: #FF1493; margin-top: 10px;">
                        {girl_math_statement(current_price, peak_price, lowest_price)}
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                # Check Walmart price
                st.markdown("### 🛒 Compare with Walmart")
                
                with st.spinner("Checking Walmart prices..."):
                    walmart_price_str = search_walmart(product_title)
                    
                    if walmart_price_str:
                        try:
                            # Extract numeric price from string
                            walmart_price_match = re.search(r'(\d+\.\d+)', walmart_price_str)
                            if walmart_price_match:
                                walmart_price = float(walmart_price_match.group(1))
                                
                                # Compare prices
                                price_diff = current_price - walmart_price
                                
                                if price_diff > 0:
                                    st.markdown(f"""
                                    <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                                        <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                            Walmart price: <b>${walmart_price:.2f}</b> (You'd save <b>${price_diff:.2f}</b> shopping at Walmart!)
                                        </p>
                                    </div>
                                    """, unsafe_allow_html=True)
                                elif price_diff < 0:
                                    st.markdown(f"""
                                    <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                                        <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                            Walmart price: <b>${walmart_price:.2f}</b> (Amazon is <b>${abs(price_diff):.2f}</b> cheaper!)
                                        </p>
                                    </div>
                                    """, unsafe_allow_html=True)
                                else:
                                    st.markdown(f"""
                                    <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                                        <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                            Walmart price: <b>${walmart_price:.2f}</b> (Same as Amazon!)
                                        </p>
                                    </div>
                                    """, unsafe_allow_html=True)
                            else:
                                st.markdown(f"""
                                <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                                    <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                        Walmart price: <b>{walmart_price_str}</b>
                                    </p>
                                </div>
                                """, unsafe_allow_html=True)
                        except:
                            st.markdown(f"""
                            <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                                <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                    Walmart price: <b>{walmart_price_str}</b>
                                </p>
                            </div>
                            """, unsafe_allow_html=True)
                    else:
                        st.markdown("""
                        <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0;">
                            <p style="font-family: 'Quicksand', sans-serif; color: #FF1493;">
                                Couldn't find this product on Walmart 😔
                            </p>
                        </div>
                        """, unsafe_allow_html=True)
                
                # Show buy button
                st.markdown("### 💝 Ready to buy?")
                
                col_buy1, col_buy2, _ = st.columns([1, 1, 2])
                with col_buy1:
                    st.markdown(f"<a href='{amazon_url}' target='_blank'><button style='background-color: #FF69B4; color: white; padding: 10px 20px; border: none; border-radius: 20px; cursor: pointer; font-family: \"Quicksand\", sans-serif; width: 100%;'>Buy on Amazon</button></a>", unsafe_allow_html=True)
                
                with col_buy2:
                    if walmart_price_str:
                        walmart_search_url = f"https://www.walmart.com/search?q={product_title.replace(' ', '+')}"
                        st.markdown(f"<a href='{walmart_search_url}' target='_blank'><button style='background-color: #FFD1DC; color: #FF1493; padding: 10px 20px; border: 2px solid #FF69B4; border-radius: 20px; cursor: pointer; font-family: \"Quicksand\", sans-serif; width: 100%;'>Check on Walmart</button></a>", unsafe_allow_html=True)
                
                # Add to search history
                if asin not in [item['asin'] for item in st.session_state.search_history]:
                    st.session_state.search_history.append({
                        'asin': asin,
                        'title': product_title,
                        'current_price': current_price,
                        'url': amazon_url
                    })
            
            except Exception as e:
                st.error(f"Error fetching data: {str(e)}")
                
                # Show friendly error recovery UI
                st.markdown("""
                <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 15px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
                    <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">Oops! Something's not working 💔</h3>
                    <p style="font-family: 'Quicksand', sans-serif; font-size: 16px; color: #FF1493; margin: 10px 0;">
                        Bestie, it's giving tech issues. Let's try something else!
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                # Recovery options
                st.markdown("### Try these options instead:")
                
                recovery_col1, recovery_col2 = st.columns(2)
                
                with recovery_col1:
                    if st.button("🔄 Restart App", use_container_width=True):
                        st.session_state.clear()
                        st.rerun()
                        
                with recovery_col2:
                    if st.button("🔍 Try a Search Instead", use_container_width=True):
                        st.session_state.search_mode = True
                        st.rerun()
                
                # Log the error for diagnosis
                import logging
                logging.error(f"Product retrieval error: {str(e)}")
    else:
        # Display a fun girly error message and offer search functionality
        error_message = get_girly_error_message()
        
        st.markdown(f"""
        <div style="background-color: #FFD1DC; padding: 20px; border-radius: 15px; margin: 15px 0; text-align: center; box-shadow: 0px 4px 12px rgba(255, 105, 180, 0.2);">
            <h3 style="font-family: 'Pacifico', cursive; color: #FF1493; margin-bottom: 15px;">Oops! Link not recognized 💔</h3>
            <p style="font-family: 'Quicksand', sans-serif; font-size: 16px; color: #FF1493; margin: 10px 0;">
                {error_message}
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("### 🔍 Try searching for your product instead!")
        
        # Create search box for product
        search_term = st.text_input("Search for a product:", placeholder="e.g., iPhone case, makeup palette...")
        
        if search_term:
            with st.spinner("Searching for products..."):
                # Add a playful message based on the search term
                themed_message = get_girly_error_message(search_term)
                
                # Display search-specific message
                st.markdown(f"""
                <div style="background-color: #FFD1DC; padding: 15px; border-radius: 15px; margin: 10px 0; text-align: center;">
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; font-size: 16px;">
                        {themed_message}
                    </p>
                    <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; font-size: 14px; margin-top: 10px;">
                        Search for <b>"{search_term}"</b> on:
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                # Links to search on platforms
                col_amazon, col_walmart = st.columns(2)
                
                with col_amazon:
                    amazon_search_url = f"https://www.amazon.com/s?k={search_term.replace(' ', '+')}"
                    st.markdown(f"<a href='{amazon_search_url}' target='_blank'><button style='background-color: #FF69B4; color: white; padding: 10px 20px; border: none; border-radius: 20px; cursor: pointer; font-family: \"Quicksand\", sans-serif; width: 100%;'>Search on Amazon</button></a>", unsafe_allow_html=True)
                    
                with col_walmart:
                    walmart_search_url = f"https://www.walmart.com/search?q={search_term.replace(' ', '+')}"
                    st.markdown(f"<a href='{walmart_search_url}' target='_blank'><button style='background-color: #FFD1DC; color: #FF1493; padding: 10px 20px; border: 2px solid #FF69B4; border-radius: 20px; cursor: pointer; font-family: \"Quicksand\", sans-serif; width: 100%;'>Search on Walmart</button></a>", unsafe_allow_html=True)

# Display search history
if st.session_state.search_history:
    st.markdown("---")
    st.markdown("### 📚 Your Search History")
    
    history_df = pd.DataFrame(st.session_state.search_history)
    
    for idx, item in enumerate(st.session_state.search_history):
        col1, col2 = st.columns([3, 1])
        with col1:
            st.markdown(f"""
            <div style="background-color: white; padding: 10px; border-radius: 10px; margin: 5px 0; border-left: 4px solid #FF69B4;">
                <p style="font-family: 'Quicksand', sans-serif; color: #FF1493; margin: 0; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 400px;">
                    {item['title']}
                </p>
                <p style="font-family: 'Quicksand', sans-serif; color: #FF69B4; margin: 0; font-size: 14px;">
                    Current price: <b>${item['current_price']:.2f}</b>
                </p>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown(f"<a href='{item['url']}' target='_blank'><button style='background-color: #FFD1DC; color: #FF1493; padding: 5px 10px; border: 1px solid #FF69B4; border-radius: 10px; cursor: pointer; font-family: \"Quicksand\", sans-serif; font-size: 12px; width: 100%;'>View Item</button></a>", unsafe_allow_html=True)

# Footer
st.markdown("""
<div class="footer">
    <p>✨ Made with Girl Math and glitter ✨</p>
</div>
""", unsafe_allow_html=True)

def girl_math_statement(current_price, peak_price, lowest_price):
    """Generate a fun girl math statement based on the price situation"""
    
    # Calculate discount percentage
    discount_percent = ((peak_price - current_price) / peak_price) * 100 if peak_price > 0 else 0
    
    # Base statements that work for any price
    general_statements = [
        f"That's like getting paid ${peak_price - current_price:.2f} to shop!",
        "Remember, if it's on sale, it's basically saving money!",
        "If you use it 10 times, it's only $" + f"{current_price/10:.2f}" + " per use!",
        "That's only " + f"{current_price/30:.2f}" + " per day for a month!",
        "It's not an expense, it's self-care.",
        "Money comes and goes, but this deal won't last forever.",
        "Buy now, your future self will thank you!",
        "It's an investment in your happiness!",
        "If you return something else, this is basically free!",
        "You've already saved money by not buying it at the peak price!",
        "You've been working hard, you deserve this."
    ]
    
    # Statements for big discounts
    big_discount_statements = [
        f"It's {discount_percent:.1f}% off, so you're actually making money!",
        "The more you spend, the more you save!",
        "If it's on sale, it's illegal NOT to buy it.",
        f"You'd be losing ${peak_price - current_price:.2f} if you don't buy it now!",
        "This is basically the universe telling you to treat yourself.",
        "It was meant to be yours. The price drop is a sign.",
        "That's a MAJOR discount! It's like they're paying you to take it!"
    ]
    
    # Statements for small discounts
    small_discount_statements = [
        "Even a small discount is still saving money!",
        "Think about the future regret of missing this deal.",
        "Sometimes the smallest discounts bring the biggest joy.",
        "You've been looking at this for weeks, it's fate.",
        "It's basically on your vision board already."
    ]
    
    # Statements if current price is close to lowest
    near_lowest_statements = [
        "It's almost at the lowest price ever. If you wait, it might sell out!",
        "It's practically at its lowest price, which means it's a good investment.",
        "This is as low as it gets, bestie. Time to add to cart!",
        "You'll regret not buying it at almost the lowest price ever."
    ]
    
    # Choose appropriate statements based on the discount
    if current_price <= lowest_price * 1.1:
        return "This is literally the LOWEST price! It would be irresponsible NOT to buy it!"
    elif discount_percent >= 20:
        combined_statements = general_statements + big_discount_statements
        import random
        return random.choice(combined_statements)
    elif discount_percent >= 5:
        combined_statements = general_statements + small_discount_statements
        import random
        return random.choice(combined_statements)
    else:
        import random
        return random.choice(general_statements)
